import './Icon.css';

function Icon({ name }) {
  return <i className={name}></i>;
}

export default Icon;
